
package javaapplication;
import java.sql.*;
public class MyConnection {
    Connection XC;
    Statement ST;
    MyConnection() 
    {
        try{
        Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
        String connectionUrl="jdbc:sqlserver://localhost:1433;databaseName=ATM;user=admin;password=1234";
        XC=DriverManager.getConnection(connectionUrl);
        ST=XC.createStatement();
        System.out.println("Connected");
        } 
        catch (Exception ex) {
            System.out.println(ex);
        }
    }
}
