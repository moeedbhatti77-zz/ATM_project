
package javaapplication;
import java.util.*;
import java.time.LocalDateTime; 
import java.time.format.DateTimeFormatter; 
import javax.swing.JFrame;
public class MainClass {


    public static void main(String[] args) {
      
       Frame f = new Frame();
       f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
       f.setLocation(400, 150);
       f.setVisible(true);
       f.setResizable(false);
    }

}
