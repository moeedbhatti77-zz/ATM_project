
package javaapplication;
import java.awt.Component;
import java.awt.event.KeyEvent;
import javax.swing.JOptionPane;
import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;
public class Frame extends javax.swing.JFrame {

    private Component frame;
    MyConnection c;
    String querry;
    int CardInUse;
    int CardPin;
    ResultSet rs = null;
    PreparedStatement pst = null;
    float bal;
    public Frame() {
        c=new MyConnection();
        initComponents();
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        transferWindow = new javax.swing.JFrame();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        rec_account = new javax.swing.JTextField();
        amount = new javax.swing.JTextField();
        cnfrm_rec_account = new javax.swing.JTextField();
        confirm = new javax.swing.JButton();
        verifyPin = new javax.swing.JPasswordField();
        main = new javax.swing.JPanel();
        header = new javax.swing.JPanel();
        bankName = new javax.swing.JLabel();
        panel_ch = new javax.swing.JPanel();
        Login = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        cardNumber = new javax.swing.JTextField();
        login = new javax.swing.JButton();
        pin = new javax.swing.JPasswordField();
        Interface = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        textArea = new javax.swing.JTextArea();
        balance = new javax.swing.JButton();
        withdraw = new javax.swing.JButton();
        deposit = new javax.swing.JButton();
        transfer = new javax.swing.JButton();
        j1 = new javax.swing.JButton();
        j2 = new javax.swing.JButton();
        j3 = new javax.swing.JButton();
        j4 = new javax.swing.JButton();
        j5 = new javax.swing.JButton();
        j6 = new javax.swing.JButton();
        j7 = new javax.swing.JButton();
        j8 = new javax.swing.JButton();
        j9 = new javax.swing.JButton();
        input = new javax.swing.JTextField();
        back = new javax.swing.JButton();
        j0 = new javax.swing.JButton();
        clear = new javax.swing.JButton();
        decimal = new javax.swing.JButton();

        transferWindow.setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        transferWindow.setTitle("Transfer Window");
        transferWindow.setAlwaysOnTop(true);
        transferWindow.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        transferWindow.setResizable(false);

        jLabel3.setText("Receiver's Account Number              :");

        jLabel4.setText("Confirm  Account Number                 :");

        jLabel5.setText("Amount to be Transfered                   :");

        jLabel6.setText("Sender's Pin                                         :");

        rec_account.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                rec_accountKeyTyped(evt);
            }
        });

        amount.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                amountKeyTyped(evt);
            }
        });

        cnfrm_rec_account.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                cnfrm_rec_accountKeyTyped(evt);
            }
        });

        confirm.setText("Confirm");
        confirm.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                confirmActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout transferWindowLayout = new javax.swing.GroupLayout(transferWindow.getContentPane());
        transferWindow.getContentPane().setLayout(transferWindowLayout);
        transferWindowLayout.setHorizontalGroup(
            transferWindowLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(transferWindowLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(transferWindowLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel4)
                    .addComponent(jLabel5)
                    .addComponent(jLabel3)
                    .addComponent(jLabel6))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(transferWindowLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(amount)
                    .addComponent(cnfrm_rec_account)
                    .addComponent(rec_account)
                    .addComponent(verifyPin))
                .addGap(52, 52, 52))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, transferWindowLayout.createSequentialGroup()
                .addContainerGap(87, Short.MAX_VALUE)
                .addComponent(confirm, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(113, 113, 113))
        );
        transferWindowLayout.setVerticalGroup(
            transferWindowLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(transferWindowLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(transferWindowLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(rec_account, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(transferWindowLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(cnfrm_rec_account, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(21, 21, 21)
                .addGroup(transferWindowLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5)
                    .addComponent(amount, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(transferWindowLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel6)
                    .addComponent(verifyPin, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(confirm, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(35, Short.MAX_VALUE))
        );

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("ATM");
        setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        setLocationByPlatform(true);

        main.setLayout(new java.awt.BorderLayout());

        header.setBackground(new java.awt.Color(153, 153, 255));

        bankName.setFont(new java.awt.Font("Tekton Pro Cond", 0, 24)); // NOI18N
        bankName.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        bankName.setText("Automated Teller Machine");

        javax.swing.GroupLayout headerLayout = new javax.swing.GroupLayout(header);
        header.setLayout(headerLayout);
        headerLayout.setHorizontalGroup(
            headerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, headerLayout.createSequentialGroup()
                .addGap(159, 159, 159)
                .addComponent(bankName, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(131, 131, 131))
        );
        headerLayout.setVerticalGroup(
            headerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, headerLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(bankName, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        main.add(header, java.awt.BorderLayout.PAGE_START);

        panel_ch.setLayout(new java.awt.CardLayout());

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel1.setText("Card Number");
        jLabel1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel1MouseClicked(evt);
            }
        });

        jLabel2.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel2.setText("PIN                 ");

        cardNumber.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cardNumberActionPerformed(evt);
            }
        });
        cardNumber.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                cardNumberKeyTyped(evt);
            }
        });

        login.setBackground(new java.awt.Color(153, 153, 255));
        login.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        login.setMnemonic('L');
        login.setText("Login");
        login.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                loginActionPerformed(evt);
            }
        });

        pin.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                pinActionPerformed(evt);
            }
        });
        pin.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                pinKeyTyped(evt);
            }
        });

        javax.swing.GroupLayout LoginLayout = new javax.swing.GroupLayout(Login);
        Login.setLayout(LoginLayout);
        LoginLayout.setHorizontalGroup(
            LoginLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, LoginLayout.createSequentialGroup()
                .addGap(127, 127, 127)
                .addGroup(LoginLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 98, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(LoginLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(login, javax.swing.GroupLayout.DEFAULT_SIZE, 200, Short.MAX_VALUE)
                    .addComponent(cardNumber)
                    .addComponent(pin, javax.swing.GroupLayout.DEFAULT_SIZE, 200, Short.MAX_VALUE))
                .addGap(152, 152, 152))
        );
        LoginLayout.setVerticalGroup(
            LoginLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(LoginLayout.createSequentialGroup()
                .addGap(48, 48, 48)
                .addGroup(LoginLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 51, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(cardNumber, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(LoginLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(pin, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(50, 50, 50)
                .addComponent(login, javax.swing.GroupLayout.PREFERRED_SIZE, 63, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(130, Short.MAX_VALUE))
        );

        panel_ch.add(Login, "card2");

        textArea.setColumns(20);
        textArea.setRows(5);
        jScrollPane1.setViewportView(textArea);

        balance.setText("Balance");
        balance.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                balanceActionPerformed(evt);
            }
        });

        withdraw.setText("Withdraw");
        withdraw.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                withdrawActionPerformed(evt);
            }
        });

        deposit.setText("Deposit");
        deposit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                depositActionPerformed(evt);
            }
        });

        transfer.setText("Transfer");
        transfer.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                transferActionPerformed(evt);
            }
        });

        j1.setText("1");
        j1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                j1ActionPerformed(evt);
            }
        });

        j2.setText("2");
        j2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                j2ActionPerformed(evt);
            }
        });

        j3.setText("4");
        j3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                j3ActionPerformed(evt);
            }
        });

        j4.setText("3");
        j4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                j4ActionPerformed(evt);
            }
        });

        j5.setText("5");
        j5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                j5ActionPerformed(evt);
            }
        });

        j6.setText("6");
        j6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                j6ActionPerformed(evt);
            }
        });

        j7.setText("8");
        j7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                j7ActionPerformed(evt);
            }
        });

        j8.setText("7");
        j8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                j8ActionPerformed(evt);
            }
        });

        j9.setText("9");
        j9.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                j9ActionPerformed(evt);
            }
        });

        input.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                inputActionPerformed(evt);
            }
        });
        input.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                inputKeyTyped(evt);
            }
        });

        back.setText(" < Login New Account");
        back.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                backActionPerformed(evt);
            }
        });

        j0.setText("0");
        j0.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                j0ActionPerformed(evt);
            }
        });

        clear.setText("C");
        clear.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                clearActionPerformed(evt);
            }
        });

        decimal.setText(".");
        decimal.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                decimalActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout InterfaceLayout = new javax.swing.GroupLayout(Interface);
        Interface.setLayout(InterfaceLayout);
        InterfaceLayout.setHorizontalGroup(
            InterfaceLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, InterfaceLayout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addGroup(InterfaceLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(back, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(deposit, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(input, javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(balance, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(withdraw, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(transfer, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(InterfaceLayout.createSequentialGroup()
                        .addComponent(j1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 26, Short.MAX_VALUE)
                        .addComponent(j2)
                        .addGap(18, 18, 18)
                        .addComponent(j4))
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, InterfaceLayout.createSequentialGroup()
                        .addGroup(InterfaceLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(InterfaceLayout.createSequentialGroup()
                                .addComponent(j3)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(j5))
                            .addGroup(InterfaceLayout.createSequentialGroup()
                                .addGroup(InterfaceLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(j8, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(decimal, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addGroup(InterfaceLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(j7, javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(j0, javax.swing.GroupLayout.Alignment.TRAILING))))
                        .addGap(18, 18, 18)
                        .addGroup(InterfaceLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(j6, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(j9, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(clear, javax.swing.GroupLayout.Alignment.TRAILING))))
                .addGap(36, 36, 36)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 380, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        InterfaceLayout.setVerticalGroup(
            InterfaceLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(InterfaceLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(InterfaceLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addComponent(jScrollPane1)
                    .addGroup(InterfaceLayout.createSequentialGroup()
                        .addComponent(back, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(balance, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(withdraw, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(deposit, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(transfer, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(input, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(InterfaceLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(j1)
                            .addComponent(j2)
                            .addComponent(j4))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(InterfaceLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(j5)
                            .addComponent(j3)
                            .addComponent(j6))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(InterfaceLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(j8)
                            .addGroup(InterfaceLayout.createSequentialGroup()
                                .addGroup(InterfaceLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(j7)
                                    .addComponent(j9))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(InterfaceLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(clear)
                                    .addComponent(j0)
                                    .addComponent(decimal))))))
                .addGap(0, 34, Short.MAX_VALUE))
        );

        panel_ch.add(Interface, "card3");

        main.add(panel_ch, java.awt.BorderLayout.CENTER);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(main, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(main, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void cardNumberActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cardNumberActionPerformed
       
    }//GEN-LAST:event_cardNumberActionPerformed

    private void loginActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_loginActionPerformed
        try 
        {
            querry = "select * from ATMCard where cardNumber = ? and pin = ?";
            pst = c.XC.prepareStatement(querry);
            pst.setInt(1,Integer.parseInt(cardNumber.getText()));
            pst.setInt(2,Integer.parseInt(pin.getText()));
            rs=pst.executeQuery();
            if(rs.next())
            {
                input.setText(Float.toString((float) 0));
                Login.setVisible(false);
                Interface.setVisible(true);
                CardInUse=Integer.parseInt(cardNumber.getText());
                CardPin=Integer.parseInt(pin.getText());
                cardNumber.setText(null);
                pin.setText(null);
                querry = "select users.fName as name  from Account inner join ATMcard on ATMcard.cardNumber=account.cardNumber  inner join users on users.accountNumber=Account.accountNumber where ATMcard.cardNumber=?";
                pst = c.XC.prepareStatement(querry);
                pst.setInt(1,CardInUse);
                rs=pst.executeQuery();
                while(rs.next())
                {
                String name=rs.getString(1);
                textArea.setText("Welcome "+name);
                }
                querry="select balance from Account where cardNumber=?";
                pst = c.XC.prepareStatement(querry);
                pst.setInt(1, CardInUse);
                rs = pst.executeQuery();
                while(rs.next())
                {
                 bal=rs.getFloat(1);
                }
            }
                else
                {
                    cardNumber.setText("");
                    pin.setText("");
                    JOptionPane.showMessageDialog(Login, "Record Does not Exist!!","Invalid Input",2);
                }
        }
        catch (SQLException ex)
        {
            System.out.println(ex);
        }
    }//GEN-LAST:event_loginActionPerformed

    private void pinActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_pinActionPerformed
        
    }//GEN-LAST:event_pinActionPerformed

    private void jLabel1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel1MouseClicked
        
    }//GEN-LAST:event_jLabel1MouseClicked

    private void j1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_j1ActionPerformed
        input.setText(input.getText()+"1");
    }//GEN-LAST:event_j1ActionPerformed

    private void j2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_j2ActionPerformed
        input.setText(input.getText()+"2");
    }//GEN-LAST:event_j2ActionPerformed

    private void j3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_j3ActionPerformed
       input.setText(input.getText()+"3");
    }//GEN-LAST:event_j3ActionPerformed

    private void j4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_j4ActionPerformed
        input.setText(input.getText()+"4");
    }//GEN-LAST:event_j4ActionPerformed

    private void j5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_j5ActionPerformed
        input.setText(input.getText()+"5");
    }//GEN-LAST:event_j5ActionPerformed

    private void j6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_j6ActionPerformed
       input.setText(input.getText()+"6");
    }//GEN-LAST:event_j6ActionPerformed

    private void j7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_j7ActionPerformed
      input.setText(input.getText()+"7");
    }//GEN-LAST:event_j7ActionPerformed

    private void j8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_j8ActionPerformed
       input.setText(input.getText()+"8");
    }//GEN-LAST:event_j8ActionPerformed

    private void j9ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_j9ActionPerformed
        input.setText(input.getText()+"9");
    }//GEN-LAST:event_j9ActionPerformed

    private void j0ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_j0ActionPerformed
        input.setText(input.getText()+"0");
    }//GEN-LAST:event_j0ActionPerformed

    private void backActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_backActionPerformed
            Login.setVisible(true);
            Interface.setVisible(false);
    }//GEN-LAST:event_backActionPerformed

    private void clearActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_clearActionPerformed
        input.setText("");
    }//GEN-LAST:event_clearActionPerformed

    private void decimalActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_decimalActionPerformed
       input.setText(input.getText()+".");
    }//GEN-LAST:event_decimalActionPerformed

    private void transferActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_transferActionPerformed
        rec_account.setText(null);
        cnfrm_rec_account.setText(null) ;
        verifyPin.setText(null);
        amount.setText(null);
        transferWindow.setVisible(true);
        transferWindow.setLocation(500,300);
        transferWindow.setSize(500,250);
        transferWindow.setResizable(false);
    }//GEN-LAST:event_transferActionPerformed

    private void inputKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_inputKeyTyped
        char hit=evt.getKeyChar();
        if(!(Character.isDigit(hit)  ||hit==KeyEvent.VK_BACK_SPACE  ||hit==KeyEvent.VK_DELETE || hit==KeyEvent.VK_DECIMAL ))
        {
            evt.consume();
        }
    }//GEN-LAST:event_inputKeyTyped

    private void inputActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_inputActionPerformed

    }//GEN-LAST:event_inputActionPerformed

    private void cardNumberKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_cardNumberKeyTyped
                char hit=evt.getKeyChar();
        if(!(Character.isDigit(hit)  ||hit==KeyEvent.VK_BACK_SPACE  ||hit==KeyEvent.VK_DELETE ))
        {
            evt.consume();
        }
    }//GEN-LAST:event_cardNumberKeyTyped

    private void pinKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_pinKeyTyped
        char hit=evt.getKeyChar();
        if(!(Character.isDigit(hit)  ||hit==KeyEvent.VK_BACK_SPACE  ||hit==KeyEvent.VK_DELETE  ))
        {
            evt.consume();
        }
        
    }//GEN-LAST:event_pinKeyTyped

    private void confirmActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_confirmActionPerformed
        
        try {
            if("".equals(rec_account.getText()) || "".equals(cnfrm_rec_account.getText()) || "".equals(verifyPin.getText()) || "".equals(amount.getText()))
            {
                JOptionPane.showMessageDialog(transferWindow, "Fill All Fields","Invalid Input",2);
                return;
            }
            if(Long.parseLong(rec_account.getText())!=Long.parseLong(cnfrm_rec_account.getText()))
            {
                JOptionPane.showMessageDialog(transferWindow, "Account Number do not Match!!","Invalid Input",1);
                rec_account.setText("");cnfrm_rec_account.setText("");verifyPin.setText("");amount.setText("");
                return;
            }
            if(Integer.parseInt(verifyPin.getText())!=CardPin)
            {
                JOptionPane.showMessageDialog(transferWindow, "Invalid Pin","Invalid Input",1);
                rec_account.setText("");cnfrm_rec_account.setText("");verifyPin.setText("");amount.setText("");
                return;
            }
            long r_account = Long.parseLong(rec_account.getText());
            querry = "select accountNumber from Account where accountNumber=?";
            pst=c.XC.prepareStatement(querry);
            pst.setLong(1, r_account);
            rs = pst.executeQuery();
            if(rs.next())
            {
                querry="update Account set balance+="+Float.parseFloat(amount.getText()) +"where accountNumber="+rs.getLong(1);
                c.ST.executeUpdate(querry);
                
                bal-=Float.parseFloat(amount.getText());
                querry="update Account set balance ="+bal+"where cardNumber= "+CardInUse;
                c.ST.executeUpdate(querry);
                
            }
            else 
            {
                JOptionPane.showMessageDialog(transferWindow, "Invalid Account Entered","Invalid Input",1);
                rec_account.setText("");cnfrm_rec_account.setText("");verifyPin.setText("");amount.setText("");
                return;
            }
            transferWindow.setVisible(false);
            textArea.setText(textArea.getText()+"\n\n\tTransfer Successful");
        } catch (SQLException ex) {
            System.out.println("ex");
        }
        
    }//GEN-LAST:event_confirmActionPerformed

    private void rec_accountKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_rec_accountKeyTyped
        char hit=evt.getKeyChar();
        if(!(Character.isDigit(hit)  ||hit==KeyEvent.VK_BACK_SPACE  ||hit==KeyEvent.VK_DELETE ))
        {
            evt.consume();
        }
    }//GEN-LAST:event_rec_accountKeyTyped

    private void cnfrm_rec_accountKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_cnfrm_rec_accountKeyTyped
        char hit=evt.getKeyChar();
        if(!(Character.isDigit(hit)  ||hit==KeyEvent.VK_BACK_SPACE  ||hit==KeyEvent.VK_DELETE  ))
        {
            evt.consume();
        }
    }//GEN-LAST:event_cnfrm_rec_accountKeyTyped

    private void amountKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_amountKeyTyped
        char hit=evt.getKeyChar();
        if(!(Character.isDigit(hit)  ||hit==KeyEvent.VK_BACK_SPACE  ||hit==KeyEvent.VK_DELETE || hit==KeyEvent.VK_DECIMAL ))
        {
            evt.consume();
        }
    }//GEN-LAST:event_amountKeyTyped

    private void balanceActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_balanceActionPerformed
        try {
            querry="select balance from Account where cardNumber=?";
            pst = c.XC.prepareStatement(querry);
            pst.setInt(1, CardInUse);
            rs = pst.executeQuery();
            while(rs.next())
            {
                bal=rs.getFloat(1);
            }
            textArea.setText(textArea.getText()+"\n\nAccount Balance is : "+Float.toString(bal));
        } catch (SQLException ex) {
            System.out.println(ex);
        }
    }//GEN-LAST:event_balanceActionPerformed

    private void depositActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_depositActionPerformed
       try{
        if(Float.parseFloat(input.getText())==0 || input.getText()==null)
            {
                textArea.setText(textArea.getText()+"\n\nEnter Deposit Amount"); 
                return;   
            }
         float depositeAmount = Float.parseFloat(input.getText());
         bal+=depositeAmount;
         querry="update Account set balance ="+bal+"where cardNumber= "+CardInUse;
         c.ST.executeUpdate(querry);
         textArea.setText(textArea.getText()+"\n\n\tDeposit Successful");
         input.setText(Float.toString((float) 0.0));
       }
       catch (Exception ex)
       {
           System.out.println(ex);
       }
       
    }//GEN-LAST:event_depositActionPerformed

    private void withdrawActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_withdrawActionPerformed
        
            if(Float.parseFloat(input.getText())==0.0 || "".equals(input.getText()))
            {
                textArea.setText(textArea.getText()+"\n\nEnter Withdraw Amount");
                return;   
            }
        try {
            float withdrawAmount = Float.parseFloat(input.getText());
            bal-=withdrawAmount;
            querry="update Account set balance ="+bal+"where cardNumber= "+CardInUse;
            c.ST.executeUpdate(querry);
            
            textArea.setText(textArea.getText()+"\n\n\tAmount Withdraw Successful");
            input.setText(Float.toString((float) 0.0));
        }
        catch (SQLException ex) {
            System.out.println(ex);
        }
        
    }//GEN-LAST:event_withdrawActionPerformed

    public static void main(String args[]) {

        java.awt.EventQueue.invokeLater(() -> {
            new Frame().setVisible(true);
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel Interface;
    private javax.swing.JPanel Login;
    private javax.swing.JTextField amount;
    private javax.swing.JButton back;
    private javax.swing.JButton balance;
    private javax.swing.JLabel bankName;
    private javax.swing.JTextField cardNumber;
    private javax.swing.JButton clear;
    private javax.swing.JTextField cnfrm_rec_account;
    private javax.swing.JButton confirm;
    private javax.swing.JButton decimal;
    private javax.swing.JButton deposit;
    private javax.swing.JPanel header;
    private javax.swing.JTextField input;
    private javax.swing.JButton j0;
    private javax.swing.JButton j1;
    private javax.swing.JButton j2;
    private javax.swing.JButton j3;
    private javax.swing.JButton j4;
    private javax.swing.JButton j5;
    private javax.swing.JButton j6;
    private javax.swing.JButton j7;
    private javax.swing.JButton j8;
    private javax.swing.JButton j9;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JButton login;
    private javax.swing.JPanel main;
    private javax.swing.JPanel panel_ch;
    private javax.swing.JPasswordField pin;
    private javax.swing.JTextField rec_account;
    private javax.swing.JTextArea textArea;
    private javax.swing.JButton transfer;
    private javax.swing.JFrame transferWindow;
    private javax.swing.JPasswordField verifyPin;
    private javax.swing.JButton withdraw;
    // End of variables declaration//GEN-END:variables

    private void Referesh() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}
